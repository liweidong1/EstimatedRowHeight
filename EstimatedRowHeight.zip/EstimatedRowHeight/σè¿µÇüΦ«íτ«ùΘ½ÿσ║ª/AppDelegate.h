//
//  AppDelegate.h
//  动态计算高度
//
//  Created by liweidong on 17/11/8.
//  Copyright © 2017年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

